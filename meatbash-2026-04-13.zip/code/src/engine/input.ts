/**
 * Input manager: tracks keyboard state.
 * Keys are checked per-frame by the game loop, not event-driven.
 */
export class InputManager {
  private keysDown = new Set<string>();
  private keysJustPressed = new Set<string>();
  private keysJustReleased = new Set<string>();

  constructor() {
    window.addEventListener('keydown', (e) => {
      const key = e.key.toUpperCase();
      if (!this.keysDown.has(key)) {
        this.keysJustPressed.add(key);
      }
      this.keysDown.add(key);
    });

    window.addEventListener('keyup', (e) => {
      const key = e.key.toUpperCase();
      this.keysDown.delete(key);
      this.keysJustReleased.add(key);
    });

    // Clear all on blur (prevent stuck keys)
    window.addEventListener('blur', () => {
      this.keysDown.clear();
    });
  }

  /** Is the key currently held down? */
  isDown(key: string): boolean {
    return this.keysDown.has(key.toUpperCase());
  }

  /** Was the key just pressed this frame? */
  justPressed(key: string): boolean {
    return this.keysJustPressed.has(key.toUpperCase());
  }

  /** Was the key just released this frame? */
  justReleased(key: string): boolean {
    return this.keysJustReleased.has(key.toUpperCase());
  }

  /** Call at end of each frame to clear frame-specific states */
  endFrame() {
    this.keysJustPressed.clear();
    this.keysJustReleased.clear();
  }

  /** Get all currently held keys (for network serialization) */
  getHeldKeys(): string[] {
    return Array.from(this.keysDown);
  }
}
