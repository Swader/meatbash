import RAPIER from '@dimforge/rapier3d-compat';
import { InputManager } from '../engine/input';
import { RapierWorld } from './rapier-world';
import type { BipedSkeleton } from './skeleton';

/**
 * Puppeteer locomotion with real physics feel.
 *
 * The torso is kinematic BUT obeys simulated gravity and collisions:
 * - Falls when no leg touches ground
 * - Can only move forward when at least one leg is grounded
 * - Collides with arena walls and rocks via raycasting
 * - Can jump (adds upward velocity, legs flail)
 *
 * Q/W kicks legs forward with impulses. The "clumsy" feel comes from:
 * - Movement only working when grounded
 * - Legs swinging wildly on kicks
 * - Losing ground contact from hard kicks → falling
 */

const MOVE_SPEED = 4.0;
const TURN_SPEED = 2.5;
const ACCEL = 12.0;
const DECEL = 10.0;
const GRAVITY = 15.0;         // Simulated gravity on kinematic torso
const JUMP_VELOCITY = 6.0;    // Jump impulse
const KICK_IMPULSE = 6.0;     // Leg kick strength
const KICK_UP = 2.0;          // Upward component of kick
const BOB_AMOUNT = 0.06;
const BOB_SPEED = 10.0;
const GROUND_SETTLE = 6.0;    // How fast torso settles to standing height
const PANIC_IMPULSE = 5.0;
const COLLISION_RADIUS = 0.5; // Torso collision check radius
const GROUND_Y = 0.0;         // Ground plane Y

export interface LocomotionState {
  lastLeg: 'left' | 'right' | 'none';
  velX: number;
  velZ: number;
  velY: number;
  yaw: number;
  posX: number;
  posY: number;
  posZ: number;
  bobPhase: number;
  initialized: boolean;
  isGrounded: boolean;         // Whether any leg touches ground
  jumpCooldown: number;        // Prevents bunny hopping
}

export function createLocomotionState(): LocomotionState {
  return {
    lastLeg: 'none',
    velX: 0, velZ: 0, velY: 0,
    yaw: 0,
    posX: 0, posY: 0, posZ: 0,
    bobPhase: 0,
    initialized: false,
    isGrounded: false,
    jumpCooldown: 0,
  };
}

export function applyBipedLocomotion(
  skeleton: BipedSkeleton,
  input: InputManager,
  dt: number,
  stamina: { current: number; max: number; regen: number },
  physics: RapierWorld,
  locoState: LocomotionState
) {
  const torso = skeleton.joints.get('torso');
  const hipL = skeleton.joints.get('hip_l');
  const hipR = skeleton.joints.get('hip_r');
  const kneeL = skeleton.joints.get('knee_l');
  const kneeR = skeleton.joints.get('knee_r');
  if (!torso || !hipL || !hipR) return;

  // Initialize
  if (!locoState.initialized) {
    const pos = torso.body.translation();
    locoState.posX = pos.x;
    locoState.posY = pos.y;
    locoState.posZ = pos.z;
    locoState.initialized = true;
  }

  let staminaCost = 0;
  locoState.jumpCooldown = Math.max(0, locoState.jumpCooldown - dt);

  // Forward direction
  const fwdX = Math.sin(locoState.yaw);
  const fwdZ = Math.cos(locoState.yaw);
  // Right direction (perpendicular)
  const rightX = Math.cos(locoState.yaw);
  const rightZ = -Math.sin(locoState.yaw);

  // ================================================================
  // GROUND CONTACT — check if lower leg bottoms are near ground
  // ================================================================
  const checkLegGround = (legJoint: { body: RAPIER.RigidBody } | undefined): boolean => {
    if (!legJoint) return false;
    const pos = legJoint.body.translation();
    // Lower leg capsule bottom ≈ center Y - halfLen - radius
    const bottom = pos.y - 0.55 / 2 - 0.13;
    return bottom < GROUND_Y + 0.15; // generous threshold
  };

  const leftGrounded = checkLegGround(kneeL);   // knee_l = lower left leg body
  const rightGrounded = checkLegGround(kneeR);
  // Fallback: also check upper legs for when beast is very low
  const leftHipGrounded = checkLegGround(hipL);
  const rightHipGrounded = checkLegGround(hipR);
  locoState.isGrounded = leftGrounded || rightGrounded || leftHipGrounded || rightHipGrounded;

  // ================================================================
  // GRAVITY + GROUND
  // ================================================================
  if (locoState.isGrounded) {
    // On ground: settle to standing height
    const targetY = skeleton.standingY;
    const diff = targetY - locoState.posY;
    if (Math.abs(diff) > 0.01) {
      locoState.posY += diff * Math.min(1, GROUND_SETTLE * dt);
    }
    // Kill downward velocity when grounded
    if (locoState.velY < 0) {
      locoState.velY = 0;
    }
  } else {
    // Airborne: apply gravity
    locoState.velY -= GRAVITY * dt;
  }

  // Apply vertical velocity
  locoState.posY += locoState.velY * dt;

  // Hard floor
  const minY = skeleton.standingY * 0.3; // Can't go below ~30% standing height
  if (locoState.posY < minY) {
    locoState.posY = minY;
    locoState.velY = 0;
  }

  // ================================================================
  // INPUT
  // ================================================================
  let wantForward = 0;
  let wantStrafe = 0;
  let wantTurn = 0;
  let isMoving = false;

  // Q = kick left leg + move forward (ONLY when grounded)
  if (input.isDown('Q') && stamina.current > 0) {
    if (locoState.isGrounded) {
      wantForward += 1;
      isMoving = true;
    }

    if (input.justPressed('Q')) {
      // Kick left upper leg forward
      hipL.body.applyImpulse(
        { x: fwdX * KICK_IMPULSE, y: KICK_UP, z: fwdZ * KICK_IMPULSE }, true
      );
      // Slight knee bend on kick
      if (kneeL) {
        kneeL.body.applyImpulse(
          { x: fwdX * KICK_IMPULSE * 0.3, y: -0.5, z: fwdZ * KICK_IMPULSE * 0.3 }, true
        );
      }
      locoState.lastLeg = 'left';
    }
    staminaCost += 10 * dt;
  }

  // W = kick right leg + move forward
  if (input.isDown('W') && stamina.current > 0) {
    if (locoState.isGrounded) {
      wantForward += 1;
      isMoving = true;
    }

    if (input.justPressed('W')) {
      hipR.body.applyImpulse(
        { x: fwdX * KICK_IMPULSE, y: KICK_UP, z: fwdZ * KICK_IMPULSE }, true
      );
      if (kneeR) {
        kneeR.body.applyImpulse(
          { x: fwdX * KICK_IMPULSE * 0.3, y: -0.5, z: fwdZ * KICK_IMPULSE * 0.3 }, true
        );
      }
      locoState.lastLeg = 'right';
    }
    staminaCost += 10 * dt;
  }

  wantForward = Math.min(wantForward, 1);

  // A/D = turn
  if (input.isDown('A')) { wantTurn += 1; staminaCost += 3 * dt; }
  if (input.isDown('D')) { wantTurn -= 1; staminaCost += 3 * dt; }

  // S = move backward (grounded only)
  if (input.isDown('S') && stamina.current > 0 && locoState.isGrounded) {
    wantForward -= 0.5;
    isMoving = true;
    staminaCost += 8 * dt;
  }

  // SPACE = jump (grounded + cooldown)
  if (input.justPressed(' ') && locoState.isGrounded && locoState.jumpCooldown <= 0 && stamina.current > 5) {
    locoState.velY = JUMP_VELOCITY;
    locoState.jumpCooldown = 0.3;
    // Kick both legs for jump visual
    hipL.body.applyImpulse({ x: 0, y: -3, z: 0 }, true);
    hipR.body.applyImpulse({ x: 0, y: -3, z: 0 }, true);
    staminaCost += 15;
  }

  // SPACE held = panic flail (after initial jump)
  if (input.isDown(' ') && !locoState.isGrounded && stamina.current > 0) {
    const t = performance.now() * 0.005;
    hipL.body.applyImpulse({
      x: Math.sin(t * 2.3) * PANIC_IMPULSE * 0.5,
      y: Math.cos(t * 1.7) * PANIC_IMPULSE * 0.3,
      z: Math.cos(t * 0.7) * PANIC_IMPULSE * 0.5,
    }, true);
    hipR.body.applyImpulse({
      x: Math.cos(t * 1.9) * PANIC_IMPULSE * 0.5,
      y: Math.sin(t * 2.1) * PANIC_IMPULSE * 0.3,
      z: Math.sin(t * 1.3) * PANIC_IMPULSE * 0.5,
    }, true);
    staminaCost += 20 * dt;
  }

  // ================================================================
  // HORIZONTAL MOVEMENT — only when grounded
  // ================================================================
  if (locoState.isGrounded) {
    const targetVX = fwdX * wantForward * MOVE_SPEED;
    const targetVZ = fwdZ * wantForward * MOVE_SPEED;
    const rate = wantForward !== 0 ? ACCEL : DECEL;
    locoState.velX += (targetVX - locoState.velX) * Math.min(1, rate * dt);
    locoState.velZ += (targetVZ - locoState.velZ) * Math.min(1, rate * dt);
  } else {
    // Airborne: slight air drag, no control
    locoState.velX *= (1 - 0.5 * dt);
    locoState.velZ *= (1 - 0.5 * dt);
  }

  // Yaw (can always turn)
  locoState.yaw += wantTurn * TURN_SPEED * dt;

  // ================================================================
  // COLLISION DETECTION — raycast in movement direction
  // ================================================================
  const moveX = locoState.velX * dt;
  const moveZ = locoState.velZ * dt;
  const moveLen = Math.sqrt(moveX * moveX + moveZ * moveZ);

  if (moveLen > 0.001) {
    const dirX = moveX / moveLen;
    const dirZ = moveZ / moveLen;

    // Cast a ray from torso center in movement direction
    const ray = new physics.rapier.Ray(
      { x: locoState.posX, y: locoState.posY, z: locoState.posZ },
      { x: dirX, y: 0, z: dirZ }
    );
    const hit = physics.world.castRay(
      ray,
      COLLISION_RADIUS + moveLen, // check distance
      true,                        // solid
      undefined, undefined, undefined,
      torso.body                   // exclude self
    );

    if (hit && hit.timeOfImpact < COLLISION_RADIUS + moveLen) {
      // Collision! Slide along the wall instead of stopping dead
      const dist = Math.max(0, hit.timeOfImpact - COLLISION_RADIUS);
      const slideRatio = moveLen > 0 ? dist / moveLen : 0;
      locoState.posX += moveX * slideRatio;
      locoState.posZ += moveZ * slideRatio;
      // Kill velocity in collision direction
      locoState.velX *= 0.1;
      locoState.velZ *= 0.1;
    } else {
      // No collision, move freely
      locoState.posX += moveX;
      locoState.posZ += moveZ;
    }
  }

  // Arena bounds (backup in case raycast misses)
  const ARENA_HALF = 33;
  locoState.posX = Math.max(-ARENA_HALF, Math.min(ARENA_HALF, locoState.posX));
  locoState.posZ = Math.max(-ARENA_HALF, Math.min(ARENA_HALF, locoState.posZ));

  // Walking bob
  if (isMoving) {
    locoState.bobPhase += BOB_SPEED * dt;
  } else {
    locoState.bobPhase *= 0.9;
  }
  const bobY = Math.sin(locoState.bobPhase) * BOB_AMOUNT * (isMoving ? 1 : 0);

  // ================================================================
  // SET TORSO POSITION
  // ================================================================
  torso.body.setNextKinematicTranslation({
    x: locoState.posX,
    y: locoState.posY + bobY,
    z: locoState.posZ,
  });

  const halfYaw = locoState.yaw / 2;
  torso.body.setNextKinematicRotation({
    x: 0, y: Math.sin(halfYaw), z: 0, w: Math.cos(halfYaw),
  });

  // Stamina
  stamina.current = Math.max(0, stamina.current - staminaCost);
  if (staminaCost === 0) {
    stamina.current = Math.min(stamina.max, stamina.current + stamina.regen * dt);
  }
}
