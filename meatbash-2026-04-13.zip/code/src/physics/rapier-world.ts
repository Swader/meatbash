import RAPIER from '@dimforge/rapier3d-compat';

/**
 * Rapier 3D physics world.
 * Owns the WASM physics simulation.
 * All rigid bodies and colliders are created through this.
 */
export class RapierWorld {
  world!: RAPIER.World;
  rapier!: typeof RAPIER;
  private initialized = false;

  async init() {
    await RAPIER.init();
    this.rapier = RAPIER;
    this.world = new RAPIER.World({ x: 0, y: -9.81, z: 0 });
    this.initialized = true;
  }

  step() {
    if (!this.initialized) return;
    this.world.step();
  }

  /** Create a ground plane collider */
  createGround(): RAPIER.RigidBody {
    const bodyDesc = this.rapier.RigidBodyDesc.fixed();
    const body = this.world.createRigidBody(bodyDesc);
    const colliderDesc = this.rapier.ColliderDesc.cuboid(40, 0.5, 40)
      .setTranslation(0, -0.5, 0)
      .setFriction(1.0)
      .setRestitution(0.05); // Very low bounce — meat doesn't bounce
    this.world.createCollider(colliderDesc, body);
    return body;
  }

  /** Create arena wall colliders (invisible boundaries) */
  createArenaWalls(halfSize: number = 35): RAPIER.RigidBody[] {
    const walls: RAPIER.RigidBody[] = [];
    const wallHeight = 10;
    const wallThickness = 1;

    const wallPositions = [
      { x: halfSize, y: wallHeight / 2, z: 0, hw: wallThickness, hh: wallHeight / 2, hd: halfSize },
      { x: -halfSize, y: wallHeight / 2, z: 0, hw: wallThickness, hh: wallHeight / 2, hd: halfSize },
      { x: 0, y: wallHeight / 2, z: halfSize, hw: halfSize, hh: wallHeight / 2, hd: wallThickness },
      { x: 0, y: wallHeight / 2, z: -halfSize, hw: halfSize, hh: wallHeight / 2, hd: wallThickness },
    ];

    for (const wp of wallPositions) {
      const bodyDesc = this.rapier.RigidBodyDesc.fixed();
      const body = this.world.createRigidBody(bodyDesc);
      const colliderDesc = this.rapier.ColliderDesc.cuboid(wp.hw, wp.hh, wp.hd)
        .setTranslation(wp.x, wp.y, wp.z)
        .setFriction(0.5)
        .setRestitution(0.3);
      this.world.createCollider(colliderDesc, body);
      walls.push(body);
    }

    return walls;
  }

  /** Create rock colliders matching visual rocks */
  createRockCollider(x: number, y: number, z: number, radius: number): RAPIER.RigidBody {
    const bodyDesc = this.rapier.RigidBodyDesc.fixed();
    const body = this.world.createRigidBody(bodyDesc);
    const colliderDesc = this.rapier.ColliderDesc.ball(radius * 0.8)
      .setTranslation(x, y, z)
      .setFriction(0.7)
      .setRestitution(0.2);
    this.world.createCollider(colliderDesc, body);
    return body;
  }

  /** Create a dynamic rigid body for a beast bone segment */
  createDynamicBody(
    x: number, y: number, z: number,
    mass: number = 1.0,
    angularDamping: number = 0.8,
    linearDamping: number = 0.5,
    lockRotations?: { x: boolean; y: boolean; z: boolean }
  ): RAPIER.RigidBody {
    const bodyDesc = this.rapier.RigidBodyDesc.dynamic()
      .setTranslation(x, y, z)
      .setLinearDamping(linearDamping)
      .setAngularDamping(angularDamping);
    if (lockRotations) {
      bodyDesc.enabledRotations(lockRotations.x, lockRotations.y, lockRotations.z);
    }
    const body = this.world.createRigidBody(bodyDesc);
    return body;
  }

  /** Create a kinematic-position body (frozen in place, moved explicitly) */
  createKinematicBody(x: number, y: number, z: number): RAPIER.RigidBody {
    const bodyDesc = this.rapier.RigidBodyDesc.kinematicPositionBased()
      .setTranslation(x, y, z);
    return this.world.createRigidBody(bodyDesc);
  }

  /** Switch a body from kinematic to dynamic */
  setBodyDynamic(
    body: RAPIER.RigidBody,
    angularDamping: number = 0.8,
    linearDamping: number = 0.5
  ) {
    body.setBodyType(this.rapier.RigidBodyType.Dynamic, true);
    body.setLinearDamping(linearDamping);
    body.setAngularDamping(angularDamping);
  }

  /** Add a capsule collider to a body (good for limbs) */
  addCapsuleCollider(
    body: RAPIER.RigidBody,
    halfHeight: number,
    radius: number,
    density: number = 1.0,
    friction: number = 0.6,
    restitution: number = 0.05
  ): RAPIER.Collider {
    const colliderDesc = this.rapier.ColliderDesc.capsule(halfHeight, radius)
      .setDensity(density)
      .setFriction(friction)
      .setRestitution(restitution);
    return this.world.createCollider(colliderDesc, body);
  }

  /** Add a ball collider to a body (good for torso, head) */
  addBallCollider(
    body: RAPIER.RigidBody,
    radius: number,
    density: number = 1.0
  ): RAPIER.Collider {
    const colliderDesc = this.rapier.ColliderDesc.ball(radius)
      .setDensity(density)
      .setFriction(0.6)
      .setRestitution(0.05);
    return this.world.createCollider(colliderDesc, body);
  }

  /** Create a revolute (hinge) joint between two bodies, optionally with a motor */
  createHingeJoint(
    body1: RAPIER.RigidBody,
    body2: RAPIER.RigidBody,
    anchor1: { x: number; y: number; z: number },
    anchor2: { x: number; y: number; z: number },
    axis: { x: number; y: number; z: number },
    limits?: { min: number; max: number },
    motor?: { targetPos: number; stiffness: number; damping: number }
  ): RAPIER.ImpulseJoint {
    const params = this.rapier.JointData.revolute(
      anchor1,
      anchor2,
      axis
    );
    if (limits) {
      params.limitsEnabled = true;
      params.limits = [limits.min, limits.max];
    }
    const joint = this.world.createImpulseJoint(params, body1, body2, true);

    // Configure motor if requested — this is a stable PD controller,
    // unlike manual torque impulses which inject energy into the system
    if (motor) {
      (joint as RAPIER.RevoluteImpulseJoint).configureMotorPosition(
        motor.targetPos,
        motor.stiffness,
        motor.damping
      );
    }

    return joint;
  }

  /** Create a ball (spherical) joint between two bodies */
  createBallJoint(
    body1: RAPIER.RigidBody,
    body2: RAPIER.RigidBody,
    anchor1: { x: number; y: number; z: number },
    anchor2: { x: number; y: number; z: number }
  ): RAPIER.ImpulseJoint {
    const params = this.rapier.JointData.spherical(anchor1, anchor2);
    return this.world.createImpulseJoint(params, body1, body2, true);
  }

  /** Apply torque to a body's joint (for QWOP locomotion) */
  applyTorqueImpulse(body: RAPIER.RigidBody, torque: { x: number; y: number; z: number }) {
    body.applyTorqueImpulse(torque, true);
  }

  /** Apply force impulse to a body */
  applyImpulse(body: RAPIER.RigidBody, impulse: { x: number; y: number; z: number }) {
    body.applyImpulse(impulse, true);
  }

  /** Get body position */
  getPosition(body: RAPIER.RigidBody): { x: number; y: number; z: number } {
    return body.translation();
  }

  /** Get body rotation */
  getRotation(body: RAPIER.RigidBody): { x: number; y: number; z: number; w: number } {
    return body.rotation();
  }

  /** Check if a body is near the ground */
  isBodyOnGround(body: RAPIER.RigidBody, threshold: number = 0.35): boolean {
    const pos = body.translation();
    return pos.y < threshold;
  }
}
