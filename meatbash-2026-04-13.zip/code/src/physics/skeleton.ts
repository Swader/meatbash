import RAPIER from '@dimforge/rapier3d-compat';
import { RapierWorld } from './rapier-world';

export interface SkeletonJoint {
  name: string;
  body: RAPIER.RigidBody;
  joint?: RAPIER.ImpulseJoint;
}

export interface BipedSkeleton {
  joints: Map<string, SkeletonJoint>;
  allBodies: RAPIER.RigidBody[];
  torsoBody: RAPIER.RigidBody;
  standingY: number;
  legLength: number;
}

/**
 * Puppeteer biped with 2-segment legs (upper + lower).
 *
 * Torso is kinematic (puppet handle). Legs are dynamic and dangle.
 * 2 segments per leg gives knee-bend visuals without the 3-segment
 * cascade problem (no feet segment = chain is short enough to be stable).
 *
 * KEY STABILITY TRICK: angular damping is EXTREME (10+) so the
 * lower leg barely moves relative to the upper leg. They act almost
 * as one rigid piece unless a strong impulse is applied.
 */
export function createBipedSkeleton(
  physics: RapierWorld,
  spawnX: number = 0,
  spawnZ: number = 0
): BipedSkeleton {
  const joints = new Map<string, SkeletonJoint>();
  const allBodies: RAPIER.RigidBody[] = [];

  // Dimensions
  const torsoHeight = 0.8;
  const torsoRadius = 0.4;
  const upperLegLen = 0.5;
  const upperLegRad = 0.16;
  const lowerLegLen = 0.55;   // Slightly longer — includes "foot"
  const lowerLegRad = 0.13;
  const hipWidth = 0.25;

  // Total leg length (for standing height calc)
  const legLength = upperLegLen + lowerLegLen + lowerLegRad; // bottom of lower capsule
  const hipOffset = torsoHeight / 2;
  const standingY = legLength + hipOffset + 0.05;

  const spawnY = standingY + 0.8; // Start slightly above, puppet lowers

  // ================================================================
  // TORSO — kinematic puppet handle
  // ================================================================
  const torsoDesc = physics.rapier.RigidBodyDesc.kinematicPositionBased()
    .setTranslation(spawnX, spawnY, spawnZ);
  const torso = physics.world.createRigidBody(torsoDesc);
  // Torso collider — used for collision queries (raycasting)
  physics.world.createCollider(
    physics.rapier.ColliderDesc.capsule(torsoHeight / 2, torsoRadius)
      .setDensity(1.0).setFriction(0.5).setRestitution(0.0),
    torso
  );
  joints.set('torso', { name: 'torso', body: torso });
  allBodies.push(torso);

  // ================================================================
  // LEGS — 2 segments each: upper leg + lower leg (includes foot)
  // EXTREME damping: 10-12 angular. This makes the 2-joint chain
  // behave almost like a single stiff rod unless kicked hard.
  // ================================================================

  for (const side of ['l', 'r'] as const) {
    const sign = side === 'l' ? -1 : 1;
    const hipX = hipWidth * sign;

    // Upper leg
    const ulY = spawnY - hipOffset - upperLegLen / 2;
    const upperLeg = physics.createDynamicBody(
      spawnX + hipX, ulY, spawnZ,
      1.0, 10.0, 5.0  // extreme angular damping
    );
    physics.addCapsuleCollider(upperLeg, upperLegLen / 2, upperLegRad, 1.0, 1.0, 0.0);
    allBodies.push(upperLeg);

    const hipJoint = physics.createHingeJoint(
      torso, upperLeg,
      { x: hipX, y: -hipOffset, z: 0 },
      { x: 0, y: upperLegLen / 2, z: 0 },
      { x: 1, y: 0, z: 0 },
      { min: -1.0, max: 1.0 }
    );
    joints.set(`hip_${side}`, { name: `hip_${side}`, body: upperLeg, joint: hipJoint });

    // Lower leg (acts as shin+foot combined)
    const llY = ulY - upperLegLen / 2 - lowerLegLen / 2;
    const lowerLeg = physics.createDynamicBody(
      spawnX + hipX, llY, spawnZ,
      0.7, 12.0, 6.0  // even more damping on lower segment
    );
    physics.addCapsuleCollider(lowerLeg, lowerLegLen / 2, lowerLegRad, 0.8, 2.0, 0.0);
    allBodies.push(lowerLeg);

    const kneeJoint = physics.createHingeJoint(
      upperLeg, lowerLeg,
      { x: 0, y: -upperLegLen / 2, z: 0 },
      { x: 0, y: lowerLegLen / 2, z: 0 },
      { x: 1, y: 0, z: 0 },
      { min: -1.0, max: 0.1 }  // knee bends backward only
    );
    joints.set(`knee_${side}`, { name: `knee_${side}`, body: lowerLeg, joint: kneeJoint });
  }

  return { joints, allBodies, torsoBody: torso, standingY, legLength };
}
