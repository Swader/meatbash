import RAPIER from '@dimforge/rapier3d-compat';
import { InputManager } from '../engine/input';
import { RapierWorld } from './rapier-world';
import type { BipedSkeleton } from './skeleton';
import { tuning } from './tuning';

/**
 * Active-ragdoll bipedal locomotion with a state machine.
 *
 * The pelvis is a DYNAMIC body. Standing is EARNED through support
 * contact, not faked through teleporting.
 *
 * STATES:
 *   SUPPORTED   — at least one foot near ground, low tilt. Full assist.
 *   STUMBLING   — support weak or tilt high. Reduced assist.
 *   FALLEN      — torso near ground or extreme tilt. NO assist; gravity wins.
 *   RECOVERING  — after a delay, ramps assist back up to recover from a fall.
 *
 * Forces:
 *   - SUPPORT SPRING (only along ground normal, only when supported):
 *     F = k*(restLen - hitDist) - d*relVel
 *   - UPRIGHT TORQUE (PD spring around X/Z, scaled by support multiplier)
 *   - DRIVE FORCE (W/S, applied at pelvis, scaled by tilt and support)
 *   - YAW TORQUE (smoothed A/D, target yaw rate)
 */

// ---- Constants ----
const PANIC_AMPLITUDE = 0.8;
const PANIC_FREQ = 6.0;
const PANIC_STAMINA_PER_SEC = 30;
const JUMP_STAMINA_COST = 15;
const ARENA_QUERY = (0x0001 << 16) | 0x0001; // raycast filter for arena group

export type LocomotionMode = 'SUPPORTED' | 'STUMBLING' | 'FALLEN' | 'RECOVERING';

export interface LocomotionState {
  jumpTimer: number;
  /** Whether at least one foot has support from the ground. */
  isGrounded: boolean;
  /** Time accumulator for the auto-cycling walk gait when W is held. */
  gaitPhase: number;
  /** Current mode in the support state machine. */
  mode: LocomotionMode;
  /** Time spent in the current mode (s). */
  modeTimer: number;
  /** Filtered raw turn input axis [-1, 1]. */
  turnAxis: number;
  /** Smoothed target yaw rate (rad/s). */
  yawRate: number;
}

export function createLocomotionState(): LocomotionState {
  return {
    jumpTimer: 999,
    isGrounded: false,
    gaitPhase: 0,
    mode: 'SUPPORTED',
    modeTimer: 0,
    turnAxis: 0,
    yawRate: 0,
  };
}

/** Critically-damped exponential smoothing toward target. */
function smooth(current: number, target: number, sharpness: number, dt: number): number {
  return current + (target - current) * (1 - Math.exp(-sharpness * dt));
}

function setMotor(
  joint: RAPIER.RevoluteImpulseJoint | undefined,
  target: number,
  stiffness: number,
  damping: number
) {
  if (!joint) return;
  joint.configureMotorPosition(target, stiffness, damping);
}

export function applyBipedLocomotion(
  skeleton: BipedSkeleton,
  input: InputManager,
  dt: number,
  stamina: { current: number; max: number; regen: number },
  physics: RapierWorld,
  locoState: LocomotionState
) {
  const pelvis = skeleton.pelvis;
  const hipL = skeleton.joints.get('hip_l');
  const hipR = skeleton.joints.get('hip_r');
  const kneeL = skeleton.joints.get('knee_l');
  const kneeR = skeleton.joints.get('knee_r');
  const ankleL = skeleton.joints.get('ankle_l');
  const ankleR = skeleton.joints.get('ankle_r');

  if (!hipL || !hipR || !kneeL || !kneeR) return;

  // CRITICAL: addForce/addTorque accumulate in this Rapier version.
  // Reset them at the start of each step before computing fresh forces.
  pelvis.resetForces(true);
  pelvis.resetTorques(true);

  let staminaCost = 0;
  locoState.jumpTimer += dt;
  locoState.modeTimer += dt;

  const pelvisPos = pelvis.translation();
  const pelvisVel = pelvis.linvel();

  // ============================================================
  // SUPPORT QUERY — single downward raycast against arena
  //
  // Returns: hit distance and normal. The pelvis raycast tells us
  // both the local ground level AND the slope direction.
  // ============================================================
  const downRay = new physics.rapier.Ray(
    { x: pelvisPos.x, y: pelvisPos.y, z: pelvisPos.z },
    { x: 0, y: -1, z: 0 }
  );
  const restLen = tuning.standingHeight;
  const maxRayDist = restLen + 2.0;
  const hit = physics.world.castRayAndGetNormal(
    downRay,
    maxRayDist,
    true,
    undefined,
    ARENA_QUERY,
    undefined,
    pelvis
  );

  let groundDist = Infinity;
  let groundNormal = { x: 0, y: 1, z: 0 };
  if (hit) {
    groundDist = hit.timeOfImpact;
    if (hit.normal) {
      groundNormal = { x: hit.normal.x, y: hit.normal.y, z: hit.normal.z };
    }
  }

  // The body counts as "supported" if the ground is within reach of the legs.
  const supportTolerance = 0.30;
  const inSupportRange = groundDist < restLen + supportTolerance;

  // Tilt: dot of pelvis up vector with world up
  const rot = pelvis.rotation();
  const pelvisUpX = 2 * (rot.x * rot.y + rot.w * rot.z);
  const pelvisUpY = 1 - 2 * (rot.x * rot.x + rot.z * rot.z);
  const pelvisUpZ = 2 * (rot.y * rot.z - rot.w * rot.x);
  // tiltCos = 1 when upright, 0 when horizontal, -1 when inverted
  const tiltCos = Math.max(-1, Math.min(1, pelvisUpY));
  const tiltDeg = Math.acos(tiltCos) * (180 / Math.PI);

  // ============================================================
  // STATE MACHINE: SUPPORTED / STUMBLING / FALLEN / RECOVERING
  // ============================================================
  const stumbleTilt = tuning.stumbleTiltDeg;
  const fallTilt = tuning.fallTiltDeg;

  const desiredMode: LocomotionMode = (() => {
    // Always become FALLEN if tilt is extreme — even mid-recovery
    if (tiltDeg > fallTilt) return 'FALLEN';
    if (!inSupportRange) {
      // No ground in reach → FALLEN
      return 'FALLEN';
    }
    if (tiltDeg > stumbleTilt) return 'STUMBLING';
    if (locoState.mode === 'FALLEN') {
      // Need a delay before recovering
      if (locoState.modeTimer >= tuning.recoverDelay) return 'RECOVERING';
      return 'FALLEN';
    }
    if (locoState.mode === 'RECOVERING') {
      // Stay in RECOVERING until ramp completes, then promote
      if (locoState.modeTimer >= tuning.recoverRamp) return 'SUPPORTED';
      return 'RECOVERING';
    }
    return 'SUPPORTED';
  })();

  if (desiredMode !== locoState.mode) {
    locoState.mode = desiredMode;
    locoState.modeTimer = 0;
  }

  // Per-mode multipliers
  let supportMul: number;       // applies to support spring + upright torque + drive
  let driveMul: number;          // separate scaling for drive force
  switch (locoState.mode) {
    case 'SUPPORTED':
      supportMul = 1.0;
      driveMul = 1.0;
      break;
    case 'STUMBLING':
      supportMul = 0.5;
      driveMul = 0.4;
      break;
    case 'FALLEN':
      supportMul = 0.0;
      driveMul = 0.0;
      break;
    case 'RECOVERING': {
      const t = Math.min(1, locoState.modeTimer / tuning.recoverRamp);
      supportMul = tuning.recoveringAssistStart +
        (tuning.recoveringAssistEnd - tuning.recoveringAssistStart) * t;
      driveMul = supportMul * 0.5;
      break;
    }
  }

  locoState.isGrounded = inSupportRange && locoState.mode !== 'FALLEN';

  // ============================================================
  // GAIT — auto-cycle when W or S held
  // ============================================================
  const wDown = input.isDown('W') && stamina.current > 0;
  const sDown = input.isDown('S') && stamina.current > 0;
  const panicDown = input.isDown(' ') && stamina.current > 0 && !locoState.isGrounded;

  if (wDown || sDown) {
    locoState.gaitPhase += dt * tuning.gaitFrequency;
  } else {
    locoState.gaitPhase *= 0.85;
  }

  let leftHipTarget: number;
  let leftKneeTarget: number;
  let rightHipTarget: number;
  let rightKneeTarget: number;

  if (panicDown) {
    const t = performance.now() * 0.001 * PANIC_FREQ;
    leftHipTarget = Math.sin(t) * PANIC_AMPLITUDE;
    rightHipTarget = Math.sin(t + Math.PI) * PANIC_AMPLITUDE;
    leftKneeTarget = -0.4 + Math.sin(t * 1.7) * 0.3;
    rightKneeTarget = -0.4 + Math.cos(t * 1.7) * 0.3;
    staminaCost += PANIC_STAMINA_PER_SEC * dt;
  } else if (wDown || sDown) {
    const lPhase = Math.sin(locoState.gaitPhase);
    const rPhase = Math.sin(locoState.gaitPhase + Math.PI);
    const lerpHip = (p: number) => p > 0
      ? p * tuning.swingHip
      : p * Math.abs(tuning.driveHip);
    const lerpKnee = (p: number) => p > 0
      ? p * tuning.swingKnee
      : tuning.driveKnee;
    leftHipTarget = lerpHip(lPhase);
    leftKneeTarget = lerpKnee(lPhase);
    rightHipTarget = lerpHip(rPhase);
    rightKneeTarget = lerpKnee(rPhase);
    staminaCost += tuning.walkStaminaCost * dt;
  } else {
    leftHipTarget = tuning.neutralHip;
    leftKneeTarget = tuning.neutralKnee;
    rightHipTarget = tuning.neutralHip;
    rightKneeTarget = tuning.neutralKnee;
  }

  // Motor multiplier: weakened when airborne or fallen
  const motorMul = locoState.mode === 'FALLEN'
    ? tuning.airMotorMul
    : (locoState.mode === 'SUPPORTED' ? 1.0 : Math.max(tuning.airMotorMul, supportMul));
  const hipK = tuning.hipStiffness * motorMul;
  const hipD = tuning.hipDamping * motorMul;
  const kneeK = tuning.kneeStiffness * motorMul;
  const kneeD = tuning.kneeDamping * motorMul;
  const ankleK = tuning.ankleStiffness * motorMul;
  const ankleD = tuning.ankleDamping * motorMul;

  setMotor(hipL.joint, leftHipTarget, hipK, hipD);
  setMotor(hipR.joint, rightHipTarget, hipK, hipD);
  setMotor(kneeL.joint, leftKneeTarget, kneeK, kneeD);
  setMotor(kneeR.joint, rightKneeTarget, kneeK, kneeD);
  if (ankleL?.joint) setMotor(ankleL.joint, 0, ankleK, ankleD);
  if (ankleR?.joint) setMotor(ankleR.joint, 0, ankleK, ankleD);

  // ============================================================
  // SUPPORT SPRING — applied along the ground normal, only when supported
  //
  // F = k * compression - d * relVel  (along normal)
  //
  // compression = restLen - hitDist (positive when too close to ground)
  // relVel = component of pelvis velocity along ground normal
  //
  // Skipped during jump holdoff so upward impulse can build height.
  // ============================================================
  const inJumpHoldoff = locoState.jumpTimer < 0.4;
  if (
    locoState.mode !== 'FALLEN' &&
    !inJumpHoldoff &&
    isFinite(groundDist)
  ) {
    const compression = restLen - groundDist;
    if (compression > -0.1) {
      // velocity along ground normal (positive = moving away from ground)
      const relVel = pelvisVel.x * groundNormal.x +
                     pelvisVel.y * groundNormal.y +
                     pelvisVel.z * groundNormal.z;
      const supportMag =
        (tuning.heightStiffness * compression - tuning.heightDamping * relVel)
        * supportMul;
      pelvis.addForce({
        x: groundNormal.x * supportMag,
        y: groundNormal.y * supportMag,
        z: groundNormal.z * supportMag,
      }, true);
    }
  }

  // ============================================================
  // UPRIGHT TORQUE — PD spring around X/Z axes
  // Scaled by support multiplier so a fallen beast doesn't self-right.
  // ============================================================
  if (supportMul > 0) {
    // Tilt error = up × worldUp = (upZ, 0, -upX)
    const errX = pelvisUpZ;
    const errZ = -pelvisUpX;
    const angVel = pelvis.angvel();
    const k = tuning.uprightStiffness * supportMul;
    const d = tuning.uprightDamping * supportMul;
    const torqueX = errX * k - angVel.x * d;
    const torqueZ = errZ * k - angVel.z * d;
    pelvis.addTorque({ x: torqueX, y: 0, z: torqueZ }, true);
  }

  // ============================================================
  // SMOOTHED TURNING — A/D → desired yaw rate → torque
  // No more snap-rotation. A/D set a target yaw rate, we filter
  // it, scale by support state, and apply a corrective torque.
  // ============================================================
  const aDown = input.isDown('A');
  const dDown = input.isDown('D');
  const rawTurn = (aDown ? 1 : 0) - (dDown ? 1 : 0);

  locoState.turnAxis = smooth(locoState.turnAxis, rawTurn, tuning.turnSharpness, dt);

  // Speed reduces turn rate slightly so high-speed turns aren't twitchy
  const horizSpeed = Math.sqrt(pelvisVel.x * pelvisVel.x + pelvisVel.z * pelvisVel.z);
  const speedMul = 1 - Math.min(1, horizSpeed / Math.max(tuning.maxSpeed, 0.001)) * 0.25;

  const targetYawRate = locoState.turnAxis * tuning.maxYawRate * supportMul * speedMul;
  locoState.yawRate = smooth(locoState.yawRate, targetYawRate, tuning.yawRateSharpness, dt);

  if (rawTurn !== 0 || Math.abs(locoState.yawRate) > 0.01) {
    const angVel = pelvis.angvel();
    const yawErr = locoState.yawRate - angVel.y;
    pelvis.addTorque({ x: 0, y: yawErr * tuning.turnTorque, z: 0 }, true);
    if (rawTurn !== 0) staminaCost += tuning.turnStaminaCost * dt;
  }

  // ============================================================
  // FORWARD DRIVE — W/S apply force in pelvis facing direction
  //
  // Drive is REDUCED when:
  // - tilt is high (don't push a falling body harder)
  // - only one foot supports (less traction)
  // - airborne (no foothold)
  // ============================================================
  if (locoState.mode !== 'FALLEN') {
    // Forward direction from pelvis quaternion (rotate (0,0,1))
    const fwdX = 2 * (rot.x * rot.z + rot.w * rot.y);
    const fwdZ = 1 - 2 * (rot.x * rot.x + rot.y * rot.y);
    const fwdLen = Math.sqrt(fwdX * fwdX + fwdZ * fwdZ) || 1;
    const fX = fwdX / fwdLen;
    const fZ = fwdZ / fwdLen;

    // Tilt-based drive scaling: full drive when upright, dropping to 0 at the
    // stumble threshold. This stops forward drive from launching a tipped beast.
    const tiltScale = Math.max(0, 1 - tiltDeg / stumbleTilt);

    let forwardMag = 0;
    if (wDown) forwardMag += tuning.forwardForce;
    if (sDown) forwardMag -= tuning.backwardForce;
    forwardMag *= driveMul * tiltScale;

    if (forwardMag !== 0) {
      pelvis.addForce({ x: fX * forwardMag, y: 0, z: fZ * forwardMag }, true);
    } else if (locoState.mode === 'SUPPORTED') {
      // Horizontal damping when standing still — prevents endless sliding
      const dampForce = 30;
      pelvis.addForce({
        x: -pelvisVel.x * dampForce,
        y: 0,
        z: -pelvisVel.z * dampForce,
      }, true);
    }
  }

  // ============================================================
  // JUMP — single upward impulse, supported + cooldown
  // ============================================================
  if (
    input.justPressed(' ') &&
    locoState.mode === 'SUPPORTED' &&
    locoState.jumpTimer >= tuning.jumpCooldown &&
    stamina.current >= JUMP_STAMINA_COST
  ) {
    const approxMass = pelvis.mass();
    pelvis.applyImpulse(
      { x: 0, y: approxMass * tuning.jumpVelocity, z: 0 },
      true
    );
    locoState.jumpTimer = 0;
    staminaCost += JUMP_STAMINA_COST;
  }

  // ============================================================
  // STAMINA
  // ============================================================
  stamina.current = Math.max(0, stamina.current - staminaCost);
  if (staminaCost === 0) {
    stamina.current = Math.min(stamina.max, stamina.current + stamina.regen * dt);
  }
}
