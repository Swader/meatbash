import RAPIER from '@dimforge/rapier3d-compat';
import { RapierWorld } from './rapier-world';
import { tuning } from './tuning';

export interface SkeletonJoint {
  name: string;
  body: RAPIER.RigidBody;
  joint?: RAPIER.RevoluteImpulseJoint;
}

export interface FootInfo {
  body: RAPIER.RigidBody;
  sensor: RAPIER.Collider;
}

export interface BipedSkeleton {
  joints: Map<string, SkeletonJoint>;
  allBodies: RAPIER.RigidBody[];
  pelvis: RAPIER.RigidBody;
  footL: FootInfo;
  footR: FootInfo;
  /** Resting pelvis Y when both feet planted, in WORLD space (includes terrain offset). */
  restingPelvisY: number;
  /** Resting pelvis HEIGHT above terrain (constant, terrain-relative). */
  restingPelvisHeightAboveGround: number;
}

/**
 * Build an active-ragdoll bipedal skeleton.
 *
 * Architecture:
 * - DYNAMIC pelvis body, hidden small capsule. NOT kinematic.
 * - 70%+ of mass in pelvis, COM positioned slightly LOW (toward hips).
 * - Real foot bodies (cuboids) with high friction and intersection sensors.
 * - Hip / knee / ankle revolute joints, all motorized.
 * - Self-collision disabled via collision groups AND per-joint
 *   `setContactsEnabled(false)` (belt and suspenders).
 *
 * The physics rig is optimized for stability and contact quality, NOT
 * for visual resemblance — the visible meat blob is a separate layer.
 */
export function createBipedSkeleton(
  physics: RapierWorld,
  spawnX: number = 0,
  spawnZ: number = 0,
  groundY: number = 0
): BipedSkeleton {
  const joints = new Map<string, SkeletonJoint>();
  const allBodies: RAPIER.RigidBody[] = [];

  // ---- Dimensions (m) ----
  // Pelvis is INTENTIONALLY small — it's a hidden locomotion shape, not
  // the visible torso. The big meaty visual blob is separate.
  const pelvisHalfH = 0.12;
  const pelvisRadius = 0.18;
  const upperLegLen = 0.42;
  const upperLegRad = 0.11;
  const lowerLegLen = 0.40;
  const lowerLegRad = 0.09;
  // Foot is a flat cuboid for stable support contact
  const footHX = 0.10;
  const footHY = 0.05;
  const footHZ = 0.16;
  const hipWidth = 0.16;

  // ---- Standing positions (calculated bottom-up so joint anchors match exactly) ----
  // Foot bottom touches ground (groundY) when standing
  const footCenterY = groundY + footHY + 0.005;
  // Ankle joint world Y = top of foot
  const ankleWorldY = footCenterY + footHY;
  const lowerLegCenterY = ankleWorldY + lowerLegLen / 2;
  const kneeWorldY = lowerLegCenterY + lowerLegLen / 2;
  const upperLegCenterY = kneeWorldY + upperLegLen / 2;
  const hipWorldY = upperLegCenterY + upperLegLen / 2;
  // Hip anchor on the pelvis is BELOW its center (lowers COM toward hips)
  const pelvisHipLocalY = -(pelvisHalfH + 0.02);
  const pelvisCenterY = hipWorldY - pelvisHipLocalY;

  // The constant "how high the pelvis sits above the terrain" — locomotion
  // uses this for support height calculations independent of slope.
  const restingPelvisHeightAboveGround = pelvisCenterY - groundY;
  tuning.standingHeight = restingPelvisHeightAboveGround;

  // ============================================================
  // PELVIS — dynamic root, MOST of the beast's mass
  // ============================================================
  // 70% of total mass in the pelvis = stable base, less prone to
  // helicopter-leg flipping.
  const pelvis = physics.createDynamicBody(
    spawnX, pelvisCenterY, spawnZ,
    5.5,    // additional mass: ~5.5 kg (heavy core)
    2.6,    // angular damping (resists tip-over wobble)
    1.4,    // linear damping (some drag)
    8       // extra solver iterations
  );
  // Smaller, smoother pelvis collider — low friction so it doesn't catch on rocks.
  physics.addCapsuleCollider(pelvis, pelvisHalfH, pelvisRadius, 1.0, 0.25, 0.0);
  joints.set('torso', { name: 'torso', body: pelvis });
  allBodies.push(pelvis);

  // ============================================================
  // Build one leg — returns the foot info
  // ============================================================
  const buildLeg = (side: 'l' | 'r'): FootInfo => {
    const sign = side === 'l' ? -1 : 1;
    const legX = spawnX + hipWidth * sign;

    // ---- Upper leg (light, motors do the work) ----
    const upperLeg = physics.createDynamicBody(
      legX, upperLegCenterY, spawnZ,
      0.5,    // light limb mass
      2.8,    // higher angular damping (softer leg motion)
      0.4,
      6
    );
    physics.addCapsuleCollider(upperLeg, upperLegLen / 2, upperLegRad, 1.0, 0.4, 0.0);
    allBodies.push(upperLeg);

    const hipJoint = physics.createHingeJoint(
      pelvis, upperLeg,
      { x: hipWidth * sign, y: pelvisHipLocalY, z: 0 },
      { x: 0, y: upperLegLen / 2, z: 0 },
      { x: 1, y: 0, z: 0 },
      { min: -1.2, max: 1.2 },
      {
        targetPos: tuning.neutralHip,
        stiffness: tuning.hipStiffness,
        damping: tuning.hipDamping,
      }
    );
    joints.set(`hip_${side}`, { name: `hip_${side}`, body: upperLeg, joint: hipJoint });

    // ---- Lower leg ----
    const lowerLeg = physics.createDynamicBody(
      legX, lowerLegCenterY, spawnZ,
      0.4, 3.4, 0.4, 6
    );
    physics.addCapsuleCollider(lowerLeg, lowerLegLen / 2, lowerLegRad, 1.0, 0.4, 0.0);
    allBodies.push(lowerLeg);

    const kneeJoint = physics.createHingeJoint(
      upperLeg, lowerLeg,
      { x: 0, y: -upperLegLen / 2, z: 0 },
      { x: 0, y: lowerLegLen / 2, z: 0 },
      { x: 1, y: 0, z: 0 },
      { min: -1.4, max: 0.05 },
      {
        targetPos: tuning.neutralKnee,
        stiffness: tuning.kneeStiffness,
        damping: tuning.kneeDamping,
      }
    );
    joints.set(`knee_${side}`, { name: `knee_${side}`, body: lowerLeg, joint: kneeJoint });

    // ---- Foot (cuboid with high friction) ----
    const foot = physics.createDynamicBody(
      legX, footCenterY, spawnZ + 0.02,
      0.3, 1.0, 0.5, 6
    );
    physics.addCuboidCollider(foot, footHX, footHY, footHZ, 1.5, tuning.footFriction, 0.0);
    allBodies.push(foot);

    // Foot sensor extending well below — catches ground from a generous range
    const sensor = physics.addSensorCollider(
      foot,
      footHX * 0.95, 0.08, footHZ * 0.95,
      { x: 0, y: -footHY - 0.06, z: 0 }
    );

    const ankleJoint = physics.createHingeJoint(
      lowerLeg, foot,
      { x: 0, y: -lowerLegLen / 2, z: 0 },
      { x: 0, y: footHY, z: -0.02 },
      { x: 1, y: 0, z: 0 },
      { min: -0.5, max: 0.5 },
      {
        targetPos: 0,
        stiffness: tuning.ankleStiffness,
        damping: tuning.ankleDamping,
      }
    );
    joints.set(`ankle_${side}`, { name: `ankle_${side}`, body: foot, joint: ankleJoint });

    return { body: foot, sensor };
  };

  const footL = buildLeg('l');
  const footR = buildLeg('r');

  return {
    joints,
    allBodies,
    pelvis,
    footL,
    footR,
    restingPelvisY: pelvisCenterY,
    restingPelvisHeightAboveGround,
  };
}
