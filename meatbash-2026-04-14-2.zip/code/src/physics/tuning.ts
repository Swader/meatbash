/**
 * Centralized tuning parameters for biped locomotion.
 * Exposed via tweakpane for live adjustment.
 *
 * All values are mutable — locomotion code reads from this object
 * each fixed step. Adjusting a slider takes effect immediately.
 */

import { Pane, BindingApi } from 'tweakpane';

export const tuning = {
  // ---- Joint motors ----
  hipStiffness: 60,
  hipDamping: 8,
  kneeStiffness: 80,
  kneeDamping: 10,
  ankleStiffness: 30,
  ankleDamping: 4,

  /** Multiplier applied to motor stiffness when airborne / fallen. */
  airMotorMul: 0.25,

  // ---- Balance: upright torque ----
  uprightStiffness: 90,
  uprightDamping: 14,

  // ---- Balance: support spring (along ground normal) ----
  /** k in F = k*(restLen - hitDist) - d*relVel. Higher = stiffer support. */
  heightStiffness: 700,
  heightDamping: 90,

  /** Target standing height for the pelvis center above the terrain (m). Auto-calibrated. */
  standingHeight: 1.05,

  // ---- State machine thresholds ----
  /** Tilt angle (degrees) above which the beast enters STUMBLING. */
  stumbleTiltDeg: 35,
  /** Tilt angle (degrees) above which the beast enters FALLEN. */
  fallTiltDeg: 70,
  /** Seconds in FALLEN before transitioning to RECOVERING. */
  recoverDelay: 0.45,
  /** Seconds RECOVERING ramp lasts before fully SUPPORTED. */
  recoverRamp: 0.7,
  /** Support multiplier at start of RECOVERING ramp. */
  recoveringAssistStart: 0.2,
  /** Support multiplier at end of RECOVERING ramp. */
  recoveringAssistEnd: 0.8,

  // ---- Gait targets (radians) ----
  neutralHip: 0.0,
  neutralKnee: -0.05,
  driveHip: -0.30,
  driveKnee: -0.05,
  swingHip: 0.55,
  swingKnee: -0.65,
  /** How fast the legs alternate when walking (cycles per second). */
  gaitFrequency: 4.0,

  // ---- Movement ----
  /** Forward push force on the pelvis (N) when W held. */
  forwardForce: 35,
  backwardForce: 20,
  /** Maximum desired walking speed (m/s) — used to taper turn rate. */
  maxSpeed: 3.0,
  jumpVelocity: 6.5,
  jumpCooldown: 0.3,

  // ---- Turning ----
  /** Maximum yaw rate when fully supported (rad/s). */
  maxYawRate: 1.4,
  /** Smoothing speed for raw turn input → filtered turn axis. Higher = snappier. */
  turnSharpness: 10.0,
  /** Smoothing speed for desired yaw rate. */
  yawRateSharpness: 8.0,
  /** Torque gain on yaw error. */
  turnTorque: 12.0,

  // ---- Foot ----
  footFriction: 1.4,

  // ---- Stamina costs (per second held) ----
  walkStaminaCost: 8,
  turnStaminaCost: 3,
};

export type Tuning = typeof tuning;

let pane: Pane | null = null;

/** Attach a native browser tooltip to a tweakpane binding. */
function tip(binding: BindingApi, text: string): BindingApi {
  const el = (binding as any).element as HTMLElement | undefined;
  if (el) {
    el.title = text;
    el.querySelectorAll('input, button, [class*="value"]').forEach((child) => {
      (child as HTMLElement).title = text;
    });
  }
  return binding;
}

export function initTuningPanel(): void {
  if (pane) return;

  pane = new Pane({ title: 'MEATBASH Tuning', expanded: false });
  const el = (pane as any).element as HTMLElement | undefined;
  if (el) {
    el.style.position = 'absolute';
    el.style.right = '12px';
    el.style.top = '40px';
    el.style.width = '300px';
  }

  // ============================================================
  // JOINT MOTORS
  // ============================================================
  const motors = pane.addFolder({ title: 'Joint Motors', expanded: false });

  tip(
    motors.addBinding(tuning, 'hipStiffness', { min: 0, max: 400, step: 1 }),
    'Hip joint motor stiffness (Nm/rad). Higher = leg fights harder to reach the target hip angle. Too high → jittery legs.'
  );
  tip(
    motors.addBinding(tuning, 'hipDamping', { min: 0, max: 50, step: 0.5 }),
    'Hip motor damping (Nm·s/rad). Resists angular velocity. Higher = smoother but slower leg swings.'
  );
  tip(
    motors.addBinding(tuning, 'kneeStiffness', { min: 0, max: 400, step: 1 }),
    'Knee joint motor stiffness. Holds the lower leg at the knee target angle. Should be slightly stronger than hip.'
  );
  tip(
    motors.addBinding(tuning, 'kneeDamping', { min: 0, max: 50, step: 0.5 }),
    'Knee motor damping. Prevents the knee from snapping rapidly between bent and straight.'
  );
  tip(
    motors.addBinding(tuning, 'ankleStiffness', { min: 0, max: 200, step: 1 }),
    'Ankle joint motor stiffness. Keeps the foot flat against the ground. Lower than hip/knee.'
  );
  tip(
    motors.addBinding(tuning, 'ankleDamping', { min: 0, max: 50, step: 0.5 }),
    'Ankle motor damping. Stops the foot from flapping around.'
  );
  tip(
    motors.addBinding(tuning, 'airMotorMul', { min: 0, max: 1, step: 0.05 }),
    'Multiplier for ALL joint motor stiffness while airborne or fallen. 0 = legs go floppy in the air, 1 = legs stay rigid.'
  );

  // ============================================================
  // BALANCE
  // ============================================================
  const balance = pane.addFolder({ title: 'Balance', expanded: false });

  tip(
    balance.addBinding(tuning, 'uprightStiffness', { min: 0, max: 1000, step: 5 }),
    'Upright torque spring stiffness. Pulls the pelvis back toward vertical. Disabled when FALLEN.'
  );
  tip(
    balance.addBinding(tuning, 'uprightDamping', { min: 0, max: 100, step: 1 }),
    'Upright torque damping. Higher = less wobble but slower recovery.'
  );
  tip(
    balance.addBinding(tuning, 'heightStiffness', { min: 0, max: 3000, step: 10 }),
    'Support spring stiffness (N/m). Pushes pelvis up along ground normal when below standing height. ONLY fires when in support range.'
  );
  tip(
    balance.addBinding(tuning, 'heightDamping', { min: 0, max: 300, step: 5 }),
    'Support spring damping (N·s/m). Resists velocity along the ground normal. Critical for stopping bounces.'
  );
  tip(
    balance.addBinding(tuning, 'standingHeight', { min: 0.5, max: 2.0, step: 0.01 }),
    'Target distance from pelvis center to ground when standing. Auto-calibrated to skeleton at startup.'
  );

  // ============================================================
  // STATE MACHINE
  // ============================================================
  const sm = pane.addFolder({ title: 'State Machine', expanded: false });

  tip(
    sm.addBinding(tuning, 'stumbleTiltDeg', { min: 0, max: 90, step: 1 }),
    'Tilt angle (°) above which the beast enters STUMBLING. Drive force fades to 0 by this angle.'
  );
  tip(
    sm.addBinding(tuning, 'fallTiltDeg', { min: 0, max: 180, step: 1 }),
    'Tilt angle (°) above which the beast enters FALLEN. All assistance disabled until RECOVERING.'
  );
  tip(
    sm.addBinding(tuning, 'recoverDelay', { min: 0, max: 3, step: 0.05 }),
    'Seconds spent in FALLEN before the beast can start RECOVERING. Lets it actually fall.'
  );
  tip(
    sm.addBinding(tuning, 'recoverRamp', { min: 0, max: 3, step: 0.05 }),
    'Duration of the RECOVERING ramp before becoming fully SUPPORTED. Slower = funnier wobble.'
  );
  tip(
    sm.addBinding(tuning, 'recoveringAssistStart', { min: 0, max: 1, step: 0.05 }),
    'Support multiplier at the START of the RECOVERING ramp.'
  );
  tip(
    sm.addBinding(tuning, 'recoveringAssistEnd', { min: 0, max: 1, step: 0.05 }),
    'Support multiplier at the END of the RECOVERING ramp.'
  );

  // ============================================================
  // GAIT
  // ============================================================
  const gait = pane.addFolder({ title: 'Gait', expanded: false });

  tip(
    gait.addBinding(tuning, 'gaitFrequency', { min: 0.5, max: 12, step: 0.1 }),
    'How fast the legs alternate when W is held (cycles per second). Higher = quicker steps.'
  );
  tip(
    gait.addBinding(tuning, 'neutralHip', { min: -0.5, max: 0.5, step: 0.01 }),
    'Hip angle (rad) when standing still. 0 = leg hangs straight down.'
  );
  tip(
    gait.addBinding(tuning, 'neutralKnee', { min: -0.5, max: 0.5, step: 0.01 }),
    'Knee angle (rad) when standing still. Slightly negative gives a natural bend.'
  );
  tip(
    gait.addBinding(tuning, 'driveHip', { min: -1, max: 0, step: 0.01 }),
    'Hip angle (rad) at the back of a stride. The driving leg pushes back to propel the body forward.'
  );
  tip(
    gait.addBinding(tuning, 'driveKnee', { min: -0.5, max: 0.5, step: 0.01 }),
    'Knee angle (rad) of the driving leg. Usually nearly straight.'
  );
  tip(
    gait.addBinding(tuning, 'swingHip', { min: 0, max: 1.2, step: 0.01 }),
    'Hip angle (rad) at the front of a stride. The swinging leg lifts forward through the air.'
  );
  tip(
    gait.addBinding(tuning, 'swingKnee', { min: -1.2, max: 0, step: 0.01 }),
    'Knee angle (rad) of the swinging leg. Bent so the foot clears the ground.'
  );

  // ============================================================
  // MOVEMENT
  // ============================================================
  const move = pane.addFolder({ title: 'Movement', expanded: false });

  tip(
    move.addBinding(tuning, 'forwardForce', { min: 0, max: 300, step: 5 }),
    'Forward force (N) applied to the dynamic pelvis when W is held. Controls walking speed.'
  );
  tip(
    move.addBinding(tuning, 'backwardForce', { min: 0, max: 200, step: 5 }),
    'Backward force (N) applied to the pelvis when S is held. Usually weaker than forward.'
  );
  tip(
    move.addBinding(tuning, 'maxSpeed', { min: 0.5, max: 10, step: 0.1 }),
    'Maximum desired walking speed (m/s). Used to taper the turn rate at high speeds so high-speed turns are not twitchy.'
  );
  tip(
    move.addBinding(tuning, 'jumpVelocity', { min: 0, max: 15, step: 0.1 }),
    'Initial upward velocity (m/s) on jump. Higher = bigger jumps.'
  );
  tip(
    move.addBinding(tuning, 'jumpCooldown', { min: 0, max: 2, step: 0.05 }),
    'Minimum time (s) between jumps. Prevents bunny-hopping.'
  );
  tip(
    move.addBinding(tuning, 'footFriction', { min: 0, max: 10, step: 0.1 }),
    'Foot collider friction coefficient. Higher = better grip. Affects walk traction. Requires respawn.'
  );

  // ============================================================
  // TURNING
  // ============================================================
  const turn = pane.addFolder({ title: 'Turning', expanded: false });

  tip(
    turn.addBinding(tuning, 'maxYawRate', { min: 0, max: 5, step: 0.05 }),
    'Maximum yaw rate (rad/s) when fully supported. The beast rotates no faster than this.'
  );
  tip(
    turn.addBinding(tuning, 'turnSharpness', { min: 1, max: 30, step: 0.5 }),
    'How quickly raw A/D input ramps up to full magnitude. Higher = snappier inputs.'
  );
  tip(
    turn.addBinding(tuning, 'yawRateSharpness', { min: 1, max: 30, step: 0.5 }),
    'How quickly the desired yaw rate is followed. Higher = sharper turns.'
  );
  tip(
    turn.addBinding(tuning, 'turnTorque', { min: 0, max: 100, step: 0.5 }),
    'Yaw correction torque gain. Higher = body matches desired yaw rate more strongly.'
  );
}
