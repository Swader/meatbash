# MEATBASH locomotion audit and rebuild plan

## Brutal diagnosis

Your current controller is not a physics locomotion system.

It is a **kinematic torso mover with decorative dynamic legs**. That single architectural choice guarantees all the symptoms you described:

- the root does not really obey gravity or impacts
- the beast cannot meaningfully balance
- bumps and rocks cannot truly topple it
- leg impulses look spastic because they are not the thing actually producing motion
- standing is faked by a height snap, not earned by support contacts

That is why it feels wrong.

If you keep the kinematic torso, you can make it look a bit better, but you will not get Gang Beasts / TRDS style "silly but real enough" falls.

## Concrete issues found in the current code

### 1) Input is sampled on the render frame, but consumed in fixed physics steps

Files:
- `src/engine/loop.ts:78-97`
- `src/engine/input.ts:36-50`

Problem:
- `justPressed` and `justReleased` are cleared once per render frame.
- Physics can run **zero**, **one**, or **multiple** fixed steps during that render frame.

So:
- on a fast render frame with **zero** fixed steps, a tap can be **lost entirely**
- on a slow frame with **multiple** fixed steps, the same tap can be **applied multiple times**

That alone can explain unreliable jumping and inconsistent kick impulses.

### 2) The torso is kinematic, so balance is fake by definition

Files:
- `src/physics/skeleton.ts:54-64`
- `src/physics/locomotion.ts:310-319`

Problem:
- the torso is `kinematicPositionBased`
- each step you call `setNextKinematicTranslation` / `setNextKinematicRotation`

Result:
- the root ignores contact forces and gravity in the way you actually need
- the legs are constrained to a moving puppet anchor that never truly has to support itself
- external hits do not drive the core body state

### 3) “Grounded” is guessed from Y height, not real support contact

File:
- `src/physics/locomotion.ts:98-114`

Problem:
- grounded state is based on `body.translation().y` minus guessed capsule dimensions
- no real contact manifold, no foot sensor, no contact normal, no support force

Result:
- the character can be considered grounded while not actually supporting weight
- standing on rocks, edges, and slopes will be nonsense
- jump gating is unreliable

### 4) Horizontal movement is not caused by the legs

Files:
- `src/physics/locomotion.ts:153-245`
- `src/physics/locomotion.ts:257-314`

Problem:
- Q/W both add impulses to legs for visuals
- but actual root motion comes from `locoState.velX/velZ` and manual root translation

Result:
- the animation and the locomotion are disconnected
- the beast slides instead of earning movement through ground reaction
- foot placement cannot matter much

### 5) Your raycast movement controller can hit your own limbs

File:
- `src/physics/locomotion.ts:265-276`

Problem:
- the ray excludes only `torso.body`
- it does not exclude the other bodies in the same skeleton

Result:
- a kicked leg can become an obstacle to the torso movement query
- this can produce random “why did I stop?” behavior

### 6) No real feet = no stable support polygon

File:
- `src/physics/skeleton.ts:96-112`

Problem:
- lower leg doubles as shin + foot
- no dedicated foot body or hidden support pad

Result:
- contact patch is tiny and poorly controllable
- you have no clean place to attach high-friction support or a ground sensor
- balance on irregular surfaces will be miserable

### 7) You are using body impulses where joint motors should be doing the work

Files:
- `src/physics/locomotion.ts:160-191`
- `src/physics/rapier-world.ts:142-173`

Problem:
- locomotion injects impulses into limb rigid bodies directly
- but you already have a helper that can create revolute joints with motor support

Result:
- energy is injected in a sloppy way
- movement becomes bursty and chaotic instead of “driven but clumsy”

### 8) Damping is being used as a substitute for control

File:
- `src/physics/skeleton.ts:80-102`

Problem:
- limb damping is extremely high
- then large impulses are used to overcome it

Result:
- limbs do not hang naturally
- they look sticky when idle and violent when excited

### 9) Mass parameter in `createDynamicBody` is misleading / unused

File:
- `src/physics/rapier-world.ts:77-93`

Problem:
- `mass` is accepted as an argument but never applied to the rigid body
- your actual mass comes from collider density

Result:
- future tuning will be confusing
- you may think you are changing body mass when you are not

## What to do instead

## The recommended architecture for a jam

Do **not** chase a pure unconstrained ragdoll that magically learns to walk.
That is a time sink.

Build a **dynamic active ragdoll with hidden assists**:

1. **Dynamic root/pelvis**, not kinematic.
2. **Joint motors** drive hips / knees / ankles toward targets.
3. **Hidden foot colliders** provide contact area and friction.
4. **Foot sensors** provide grounded state.
5. **A soft upright + height controller** assists balance only while support exists.
6. **When support is lost, remove or greatly reduce assist**, and let gravity win.

That gives you:
- real falling
- real reaction to hits
- balance that matters
- silly motion because gains can be underdamped and imperfect
- a system that generalizes to 2, 4, 6, 8 legs by changing gait data, not physics philosophy

## The key mindset shift

You do **not** want “no cheating.”
You want **physically plausible cheating**.

The correct cheat is:
- a **dynamic** body with **force/torque assistance**
- not a **kinematic teleporting** body

That difference is everything.

## The rebuild plan

## Phase 0 — fix the obvious bugs first

### A. Fix input latching immediately

Move `justPressed` / `justReleased` consumption to the fixed step.
Do not clear edge-triggered input at render end.

Preferred pattern:
- keyboard events append to a queue
- each fixed step consumes the queued presses/releases once
- held keys remain separate from edge-triggered keys

### B. Delete the manual torso move-and-slide controller

Remove this entire idea:
- local `posX/posY/posZ`
- raycast-based torso collision steering
- standingY snap
- fake gravity on the root state

Once the root is dynamic, the physics world should own those values.

## Phase 1 — rebuild the skeleton correctly

### A. Split visuals from physics harder

Use ugly invisible physics bodies.
Keep the meat visuals completely separate.

Your physics rig should be optimized for:
- stability
- contact quality
- readable tuning

Not for visual resemblance.

### B. Use a smaller pelvis/root collider

Right now the torso collider is large and likely too involved in leg space.
Use a more compact root collider around the hips / belly.

Suggested starting rig for a biped:
- **pelvis/root**: capsule or sphere around hip mass
- **upper leg L/R**
- **lower leg L/R**
- **foot L/R** hidden cuboid or capsule pad

Optional:
- chest/head stays visual only for now

### C. Add real feet

This is non-negotiable.

Use hidden feet with:
- a short, flat collider
- high friction
- low-ish mass
- optional separate sensor collider slightly below it

The foot is where support happens.
Without it, you are trying to stand on shins.

### D. Make the root dynamic

Root should be a dynamic body with gravity and collisions.
No kinematic translation.

### E. Explicitly disable contacts on directly linked joint pairs

Even if the engine default happens to be what you want, do not rely on defaults.
Make it explicit for each hip/knee/ankle joint.

## Phase 2 — replace impulses with joint targets

### A. Every actuated joint gets a motor target

Per leg, you want at minimum:
- hip target angle
- knee target angle
- ankle / foot target angle if you have feet

These targets are updated every fixed step.

### B. Use stateful gait phases, not raw impulses

Each leg should have a phase like:
- `stance`
- `lift`
- `swing`
- `plant`

Then keys do this:
- Q advances gait group A
- W advances gait group B

For a biped:
- Q = left leg swing intent
- W = right leg swing intent

For a quadruped:
- Q = left pair / diagonal pair A
- W = right pair / diagonal pair B

For a hexapod:
- tripod groups

The generic part is the same. Only the group definitions differ.

### C. Keep stance legs planted and swing legs sloppy

- stance leg: more extension, higher support, foot wants to stay under/behind COM
- swing leg: knee bends, hip flexes, foot lifts, then reaches forward

That creates locomotion that feels active but not robotic.

## Phase 3 — add balance assistance that can fail

This is the part you were trying to fake with the puppet string.
Do it with forces, not teleporting.

### A. Upright torque controller

Apply torque to the root to align the beast’s up vector toward world up, or toward averaged ground normal on slopes.

Use a spring-damper style controller:
- proportional term for tilt error
- damping term for angular velocity

Important:
- strong when feet are grounded
- much weaker in the air
- weaker during attacks / panic flail

That way the beast can recover, but not perfectly.

### B. Height spring, only while supported

Instead of snapping the root to `standingY`, apply an upward force:

`F_y = k_h * (targetHeight - currentHeight) - c_h * rootLinVelY`

Only do this when at least one support foot is grounded.

No support contact:
- no height spring
- gravity takes over

That gets you the "falls when losing contact" behavior you want.

### C. Support polygon / COM check

For every grounded foot, collect a support point on XZ.
Compute the support polygon.
Project the center of mass onto XZ.

Rules:
- COM well inside polygon → normal assist
- COM near edge → reduced confidence / stronger lean corrections
- COM outside polygon → character is unstable, allow tipping/falling

This is the right generalization path for any x-ped.

You do **not** need a full skeletal stability solver.
You need:
- grounded support points
- projected COM
- a controller that knows when it no longer deserves to save the body

## Phase 4 — make attacks and locomotion share the same budget

For a game about losing mass, attacks should destabilize you.
So:
- attack impulses temporarily reduce upright gain
- hard swings shift COM
- getting clipped at the foot / hip matters
- stamina scales motor strength and recovery

Then combat creates funny self-sabotage for free.

## Minimal shippable implementation for the jam

If time is short, ship this version:

### Root
- 1 dynamic pelvis/root capsule

### Each leg
- thigh capsule
- shin capsule
- hidden foot cuboid
- hip revolute joint
- knee revolute joint
- ankle revolute or fixed-ish joint
- foot sensor collider

### Controller layers
1. **Input layer**
   - fixed-step latched input
2. **Gait layer**
   - left/right or group A/B phase state machine
3. **Motor layer**
   - target joint angles from gait phase
4. **Balance layer**
   - root upright torque
   - root height spring when supported
5. **Failure layer**
   - if COM leaves support or support count drops to 0, reduce assistance

This is enough to get a biped and a quadruped working.

## How to generalize to arbitrary x-peds

Do **not** make one giant universal solver that infers gait from arbitrary mesh blobs.
That is the wrong abstraction.

Make a generic **controller framework** with archetype-specific data.

## Suggested data model

```ts
interface MotorizedJointDef {
  name: string;
  joint: RAPIER.RevoluteImpulseJoint;
  restAngle: number;
  minAngle: number;
  maxAngle: number;
  stiffness: number;
  damping: number;
}

interface EndEffectorDef {
  name: string;
  body: RAPIER.RigidBody;
  footCollider: RAPIER.Collider;
  sensorCollider: RAPIER.Collider;
  gaitGroup: string; // e.g. "A", "B", "left", "right", "tripodA"
  nominalPlantOffset: { x: number; y: number; z: number };
}

interface ArchetypeLocomotionDef {
  rootBody: RAPIER.RigidBody;
  joints: Record<string, MotorizedJointDef>;
  endEffectors: EndEffectorDef[];
  supportHeight: number;
  uprightGain: number;
  heightGain: number;
  gaitGroups: Record<string, string[]>; // group name -> effector names
}
```

Then locomotion code only needs to know:
- what the actuators are
- which end-effectors belong to which gait groups
- what the nominal support height is

That scales from biped to octoped.

## What not to do

### 1. Do not keep the root kinematic and hope better leg code fixes it
It will not.

### 2. Do not drive locomotion with COM impulses to limbs
That is why it looks spastic.

### 3. Do not infer grounded state from Y thresholds
Use contacts or sensors.

### 4. Do not try to solve arbitrary creature stability from the full flesh mesh
Use the hidden physical rig.

### 5. Do not add more body segments until the 2-leg version is stable
More joints before stability = more chaos.

## Specific package advice

### Keep
- `@dimforge/rapier3d-compat`
- `three`

### Add
- **one** live tuning panel library: `tweakpane` or `lil-gui`

Reason:
You are entering gain-tuning hell.
You need live controls for:
- hip stiffness/damping
- knee stiffness/damping
- upright gain/damping
- height spring gain/damping
- foot friction
- stride amplitude
- swing duration
- stance duration
- assistance multiplier when airborne

Without a live tuning panel, you will waste massive time editing constants blindly.

### Do not add
- another physics engine
- IK middleware
- animation middleware

Not for the jam.
The missing piece is controller architecture, not dependency count.

## Suggested initial tuning values

These are rough starting points, not truth.

### Physics
- global solver iterations: bump above default
- internal PGS iterations: bump above default
- add extra solver iterations on the beast bodies only if needed
- tiny contact skin on locomotion colliders

### Root
- root mass heavier than each leg segment
- center of mass slightly low / near pelvis
- moderate angular damping, not ridiculous

### Feet
- friction high
- restitution near zero
- contact patch wider than visual foot suggests

### Motors
- hip: medium stiffness, medium damping
- knee: a bit stiffer than hip
- airborne motor gains lower than grounded gains
- attack moves temporarily override local joint targets but not the whole controller

### Assistance
- upright gain: enough to recover from mild wobble
- not enough to ignore a shove
- height spring: enough to keep supported stance
- disabled when no foot support

## Concrete implementation order

### Day 1
- fix input latching
- make root dynamic
- remove manual torso translation logic

### Day 2
- add feet + foot sensors
- store grounded state per foot
- explicit joint contact disable for linked parts

### Day 3
- switch hip/knee control to motor targets
- add 4-phase gait state machine for biped

### Day 4
- add upright torque + height spring
- add COM/support check

### Day 5
- retune, then implement quadruped by reusing the same framework

## Fast fallback if the pure dynamic root becomes too chaotic

If you are close to the deadline and full active ragdoll is still too unstable:

Use a **ghost target** approach:
- keep the root dynamic
- create an invisible non-colliding target transform
- pull the root toward that target with spring forces / torques
- never teleport the root

That still allows falling, bumps, and recovery, unlike a kinematic root.

This is the acceptable cheat if you need to ship.

## Final recommendation

Your current setup is fighting your game design.

You want:
- gravity-sensitive comedy
- balance-dependent combat
- falling off rocks
- silly but meaningful control

That requires:
- **dynamic root**
- **motorized joints**
- **real support contacts**
- **soft assistance that can fail**

The path forward is not “better puppet string math.”
It is deleting the puppet string and replacing it with a force-based active ragdoll controller.
