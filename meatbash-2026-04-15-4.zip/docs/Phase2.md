# MEATBASH — Next Steps Plan (April 14, 2026)

## Current State

Phase 1 core loop is solid:
- Active-ragdoll bipedal locomotion with WASD, jump, fall/recovery state machine
- Terrain heightfield with real rock colliders (convex hulls matching visuals)
- Tweakpane tuning panel for live parameter adjustment
- Meat blob visuals with fresnel rim glow, jiggle physics, googly eyes
- Arena with rocks, walls, dust particles, dramatic lighting
- 120 FPS, clean architecture

**What's missing for a playable game:**
1. Homepage (no way to start a match or pick a beast)
2. Default beasts (only one biped exists)
3. Two-beast combat (damage, second beast, bot AI)
4. Multiplayer (WebSocket server, match codes)
5. Gene Lab (beast creation)
6. Darwin Certification

## Priority Order (what makes the biggest impact soonest)

### BLOCK 1: Playable Demo (Days 1-3)
**Goal: Someone visits the site, picks a beast, fights a bot, has fun.**

#### 1A. Homepage / Game Shell
**Files:** `src/ui/home-screen.ts`, `src/ui/game-shell.ts`, `src/main.ts`, `src/index.html`

The homepage is the first thing people see. Based on the excalidraw sketch, layout is:

```
┌─────────────────────────────────────────────────────────┐
│                                                          │
│  ┌─────────────┐   ┌──────────────────┐  ┌───────────┐ │
│  │ Join match   │   │                  │  │Your beasts│ │
│  │ [code input] │   │   3D beast       │  │           │ │
│  │              │   │   preview on     │  │ Bronco(4) │ │
│  │ Make a match │   │   turntable      │  │ Henpeck(2)│ │
│  │              │   │                  │  │ ...       │ │
│  │              │   │  "Make your      │  │           │ │
│  │              │   │   beast" label   │  │-----------│ │
│  │              │   │                  │  │ DEFAULTS  │ │
│  │              │   │                  │  │ Chonkus   │ │
│  │              │   │                  │  │ Skitter   │ │
│  └─────────────┘   └──────────────────┘  └───────────┘ │
│                                                          │
│  ┌──────────────────────────────────────────────────────┐│
│  │              Darwin Certification                     ││
│  └──────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

**Key UX decisions:**
- The 3D preview in the center shows whichever beast is currently selected in the beast list
- Clicking "Make your beast" opens the Gene Lab (future — grayed out initially with "Coming soon")
- "Darwin Certification" button opens certification flow (future — same treatment)
- "Join match" has a text input for MEAT-XXXX codes
- "Make a match" creates a match and shows the code to share
- Beast list has TWO sections: "Your beasts" (user-created, empty initially) and "Defaults" (always available premade beasts)
- **Quick Play**: clicking a default beast + "Make a match" should get you into a bot fight in <3 seconds
- The whole page has the MEATBASH title at top, whimsical, pulsating
- Background: the 3D arena scene renders behind the UI panels (semi-transparent panels over the 3D view)

**Implementation approach:**
- Game shell manages screen state: HOME | ARENA | LAB | CERTIFICATION
- Homepage is an HTML overlay over the Three.js canvas
- Selecting a beast spawns it on the turntable in the 3D preview
- Panels use CSS backdrop-filter for glassmorphism over the 3D scene
- The arena is always rendering in the background (just with a stationary camera and no beast until one is selected)

#### 1B. Default/Premade Beasts
**Files:** `src/beast/premades.ts`, `src/beast/beast-data.ts`

Create 2 default beasts as serialized JSON configs:

1. **Chonkus** (Bipedal) — The one we already have, essentially. Fat pink blob, two legs, googly eyes. Tank playstyle.
2. **Stomper** (Quadruped) — Four-legged beast. Requires implementing quadruped skeleton + locomotion.

Each beast definition includes:
- Archetype (bipedal/quadruped)
- Skeleton joint positions + limits
- Visual config (segment sizes, colors)
- Default key bindings
- Name, description, icon

**For the quadruped**, we need:
- `src/physics/skeleton-quad.ts` — 4-leg skeleton builder
- `src/physics/locomotion-quad.ts` — Quadruped locomotion (Q/W = left/right pair stride, A/D = turn)
- Or better: generalize the existing skeleton/locomotion to support both via archetype config

#### 1C. Two Beasts + Bot AI
**Files:** `src/combat/match.ts`, `src/combat/bot-ai.ts`, `src/combat/hud.ts`

- Spawn two beasts in the arena (player + bot)
- Bot AI: simple state machine — wander toward player, occasionally attack, sometimes panic
- Basic combat HUD: mass bars (top), timer (center), stamina (bottom)
- Match flow: select beasts → 3-second countdown → 3-minute fight → result screen
- **No damage system yet** — just two beasts bumping into each other, getting knocked down, recovering. The fun is in the clumsy physics. Damage comes in Block 2.

### BLOCK 2: Combat & Damage (Days 4-6)
**Goal: Hits matter. Meat flies off. Limbs get severed.**

#### 2A. Collision Damage
**Files:** `src/physics/damage.ts`

- Hook into Rapier contact events between beast bodies
- Calculate damage from relative velocity × mass × material multiplier
- Apply as SDF volume subtraction at contact point (simplified: just reduce a "meat HP" per body segment for now)
- Spawn meat chunk particles at impact point
- Update mass bars in HUD

#### 2B. Limb Severance
**Files:** `src/physics/severance.ts`

- When a body segment's HP reaches zero, break the Rapier joint
- Severed limb becomes a free physics prop
- Remaining beast adapts: loses that limb's locomotion contribution
- Visual: limb detaches and flies off

#### 2C. Visual Meat Chunks
**Files:** `src/particles/meat-chunks.ts`

- GPU particle system for meat debris on impact
- Pink blobs that bounce and fade
- Splatter decals on arena surface

### BLOCK 3: Networking (Days 7-9)
**Goal: Two players can fight each other over the internet.**

#### 3A. WebSocket Server
**Files:** `server/index.ts`, `server/match-manager.ts`, `server/ws-handler.ts`

- Bun WebSocket server on DO droplet
- Match creation → MEAT-XXXX code
- Input relay between players
- Beast serialization exchange at match start

#### 3B. Client Networking
**Files:** `src/network/ws-client.ts`, `src/network/protocol.ts`, `src/network/interpolation.ts`

- WebSocket client for multiplayer
- Host-authoritative: P1 runs physics, broadcasts state
- P2 sends inputs, receives state, interpolates
- Spectator mode: read-only state feed

### BLOCK 4: Gene Lab (Days 10-12)
**Goal: Players can sculpt their own beasts.**

#### 4A. SDF Sculpting System
**Files:** `src/sdf/sdf-volume.ts`, `src/sdf/sdf-ops.ts`, `src/sdf/marching-cubes.ts`

- SDF blob data structure
- Add/subtract/material tools
- Marching cubes mesher (64³ grid → BufferGeometry)

#### 4B. Gene Lab UI
**Files:** `src/lab/gene-lab.ts`, `src/lab/sculpt-brush.ts`, `src/lab/joint-editor.ts`

- Archetype picker
- 3D sculpting viewport
- Brush tools, joint repositioning
- Stats sidebar
- Key binding panel
- Save beast to garage

### BLOCK 5: Certification & Polish (Days 13-16)
**Goal: Darwin Certification works. Game is polished and submittable.**

- Three certification challenges
- Remaining archetypes (slider, wigglers, hexapod, octoped)
- 6-8 premade beasts
- Vibeverse portal
- Post-match stats (stretch)
- Final polish, bug fixes, playtesting

---

## Agent Task Assignments for Block 1

These can run in parallel:

### Agent A: Game Shell + Homepage UI
**Context:** Read `src/main.ts`, `src/index.html`, `src/ui/debug-hud.ts`
**Task:** Build the game shell state machine and homepage HTML overlay. The homepage should render ON TOP of the 3D scene (which continues to render the arena in the background). Create panels for: left sidebar (join/make match buttons), center (3D beast preview with "Make your beast" label), right sidebar (beast list with "Defaults" section). Style should be whimsical, semi-transparent dark panels with rounded corners, organic/meaty color accents. The MEATBASH title should be big, gooey-looking, and pulse gently. All UI is DOM elements over the canvas, not Three.js.

### Agent B: Quadruped Skeleton + Locomotion
**Context:** Read `src/physics/skeleton.ts`, `src/physics/locomotion.ts`, `src/physics/tuning.ts`
**Task:** Create a quadruped (4-legged) skeleton and locomotion system. Can either duplicate/adapt the biped approach or generalize it. The quad should have: spine, 4 hip joints, 4 knee joints, 4 feet with sensors. Locomotion: W/S = forward/back, A/D = turn. Gait is alternating left-pair/right-pair (like a trotting dog). Should feel stably clumsy — easier to control than the biped but less agile. Use the same tuning.ts pattern for live parameter adjustment.

### Agent C: Premade Beast Definitions + Beast Selector
**Context:** Read `src/beast/beast-instance.ts`, `src/beast/test-beast.ts`
**Task:** Create a beast definition format (JSON-serializable config) and two premade beasts: Chonkus (bipedal, existing proportions) and Stomper (quadruped, needs Agent B's skeleton). Build a beast factory that creates a BeastInstance from a definition. Create a simple beast selector UI that shows beast cards with name, archetype icon, and a preview. Selected beast should spawn on the turntable in the homepage 3D preview.

### Agent D: Bot AI + Match Flow
**Context:** Read `src/engine/loop.ts`, `src/beast/beast-instance.ts`, `src/physics/locomotion.ts`
**Task:** Create a bot AI that controls a second beast. The bot should: move toward the player, attempt to bump into them, occasionally jump, sometimes panic-flail when airborne. Keep it simple — random inputs biased toward the player. Also build the match state machine: beast selection → spawn both beasts → 3-second countdown → 3-minute timer → result screen (winner by mass % or draw). The match should be startable from the homepage via a "Quick Fight" flow.

---

## Technical Notes

### State Management
The game needs a simple state machine, NOT a framework:
```typescript
type GameScreen = 'HOME' | 'ARENA' | 'LAB' | 'CERTIFICATION';

class GameShell {
  currentScreen: GameScreen = 'HOME';
  // Each screen manages its own DOM elements and Three.js scene state
  transition(to: GameScreen) { ... }
}
```

### Beast Definition Format
```typescript
interface BeastDefinition {
  id: string;
  name: string;
  description: string;
  archetype: 'bipedal' | 'quadruped';  // future: slider, wiggler, etc.
  isDefault: boolean;  // true for premade beasts
  skeleton: {
    // Joint positions, limits, etc. — archetype-specific
  };
  visuals: {
    // Segment sizes, colors, eye positions
  };
  bindings: Record<string, string>;  // key → joint action mapping
}
```

### Homepage 3D Preview
The homepage renders the arena in the background with a stationary camera. When a beast is selected from the list, it spawns on a small turntable platform at the arena center and slowly rotates. The camera zooms in slightly. This gives an instant "feel" for the beast without needing a separate preview renderer.